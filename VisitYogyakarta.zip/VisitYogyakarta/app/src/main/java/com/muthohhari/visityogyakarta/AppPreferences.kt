package com.muthohhari.visityogyakarta

object AppPreferences {
}